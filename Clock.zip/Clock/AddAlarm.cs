﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clock
{
    public partial class AddAlarm : Form
    {
        Alarm alarm;
        AlarmList alarmList;
        public AddAlarm()
        {
            InitializeComponent();
            alarm = new Alarm();
            alarmList = new AlarmList();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            //alarmList.listBoxTime.Items.Add("хуй");
            //alarmList.Show();
        }

        private void checkBoxExactDate_CheckedChanged(object sender, EventArgs e)
        {
            dateTimePickerDate.Enabled = ((CheckBox)sender).Checked;
        }

        private void buttonCansel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
